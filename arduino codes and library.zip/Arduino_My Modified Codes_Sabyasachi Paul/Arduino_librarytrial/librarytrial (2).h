


#ifndef librarytrial_h
#define librarytrial_h

#include <inttypes.h>
#include <Arduino.h>



class librarytrial
{
  

  public:
    void setup_system();
    void looping_system();
};



#endif
