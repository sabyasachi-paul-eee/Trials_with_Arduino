


#ifndef textboxreceive_h
#define textboxreceive_h

#include <inttypes.h>
#include <Arduino.h>
#include "textboxfunc.h"



class textboxreceive
{


  public:
   char textboxdata();

  private:
};



#endif
