


#ifndef testlib_h
#define testlib_h

#include <inttypes.h>
#include <Arduino.h>



class testlib
{


  public:
    void setup_system();
    void looping_system();

  private:
};



#endif
