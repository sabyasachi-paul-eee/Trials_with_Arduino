


#ifndef textboxfunc_h
#define textboxfunc_h

#include <inttypes.h>
#include <Arduino.h>



class textboxfunc
{


  public:
    boolean GetText(char *txt, int len);
    void StrClear(char *str, char length);
    char StrContains(char *str, char *sfind);

  private:
};



#endif
